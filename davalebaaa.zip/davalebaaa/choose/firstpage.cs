﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace choose
{
    public partial class firstpage : Form
    {
        public firstpage()
        {
            InitializeComponent();
        }

        private void Customers_Click(object sender, EventArgs e)
        {

        }

        private void Orders_Click(object sender, EventArgs e)
        {

        }

        private void product_Click(object sender, EventArgs e)
        {

        }

        private void Suplier_Click(object sender, EventArgs e)
        {

        }
    }
}
