﻿namespace choose
{
    partial class Products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonforreadproducts = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numericUpDownforlownumber = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownfortopnumber = new System.Windows.Forms.NumericUpDown();
            this.buttonforshowavailableproduct = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.buttonproductsalesstate = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxforproductname = new System.Windows.Forms.TextBox();
            this.textBoxforsupplierID = new System.Windows.Forms.TextBox();
            this.textBoxforunitprice = new System.Windows.Forms.TextBox();
            this.textBoxforpackage = new System.Windows.Forms.TextBox();
            this.textBoxfordeleteID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownforlownumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownfortopnumber)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(114, 32);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(356, 190);
            this.dataGridView1.TabIndex = 0;
            // 
            // buttonforreadproducts
            // 
            this.buttonforreadproducts.Location = new System.Drawing.Point(251, 238);
            this.buttonforreadproducts.Name = "buttonforreadproducts";
            this.buttonforreadproducts.Size = new System.Drawing.Size(75, 23);
            this.buttonforreadproducts.TabIndex = 1;
            this.buttonforreadproducts.Text = "Read";
            this.buttonforreadproducts.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(319, 415);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Create";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(563, 415);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "delete";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(114, 415);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 1;
            this.button4.Text = "Update";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(494, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search product by price range";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(494, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Show available product";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(494, 258);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "product sales state";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(498, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Low";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(499, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 24);
            this.label5.TabIndex = 3;
            this.label5.Text = "Top";
            // 
            // numericUpDownforlownumber
            // 
            this.numericUpDownforlownumber.Location = new System.Drawing.Point(549, 92);
            this.numericUpDownforlownumber.Name = "numericUpDownforlownumber";
            this.numericUpDownforlownumber.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownforlownumber.TabIndex = 4;
            // 
            // numericUpDownfortopnumber
            // 
            this.numericUpDownfortopnumber.Location = new System.Drawing.Point(549, 137);
            this.numericUpDownfortopnumber.Name = "numericUpDownfortopnumber";
            this.numericUpDownfortopnumber.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownfortopnumber.TabIndex = 4;
            // 
            // buttonforshowavailableproduct
            // 
            this.buttonforshowavailableproduct.Location = new System.Drawing.Point(582, 214);
            this.buttonforshowavailableproduct.Name = "buttonforshowavailableproduct";
            this.buttonforshowavailableproduct.Size = new System.Drawing.Size(75, 23);
            this.buttonforshowavailableproduct.TabIndex = 1;
            this.buttonforshowavailableproduct.Text = "Show";
            this.buttonforshowavailableproduct.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(699, 112);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 1;
            this.button5.Text = "Search";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // buttonproductsalesstate
            // 
            this.buttonproductsalesstate.Location = new System.Drawing.Point(582, 305);
            this.buttonproductsalesstate.Name = "buttonproductsalesstate";
            this.buttonproductsalesstate.Size = new System.Drawing.Size(75, 23);
            this.buttonproductsalesstate.TabIndex = 1;
            this.buttonproductsalesstate.Text = "Show";
            this.buttonproductsalesstate.UseVisualStyleBackColor = true;
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.back.Location = new System.Drawing.Point(12, 32);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 1;
            this.back.Text = "<   back";
            this.back.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(88, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Enter Product name";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(88, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Enter Supplier ID";
            this.label7.Click += new System.EventHandler(this.label6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(88, 329);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Enter Unit price";
            this.label8.Click += new System.EventHandler(this.label6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(88, 355);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Enter Package";
            this.label9.Click += new System.EventHandler(this.label6_Click);
            // 
            // textBoxforproductname
            // 
            this.textBoxforproductname.Location = new System.Drawing.Point(239, 274);
            this.textBoxforproductname.Name = "textBoxforproductname";
            this.textBoxforproductname.Size = new System.Drawing.Size(100, 20);
            this.textBoxforproductname.TabIndex = 6;
            // 
            // textBoxforsupplierID
            // 
            this.textBoxforsupplierID.Location = new System.Drawing.Point(239, 302);
            this.textBoxforsupplierID.Name = "textBoxforsupplierID";
            this.textBoxforsupplierID.Size = new System.Drawing.Size(100, 20);
            this.textBoxforsupplierID.TabIndex = 6;
            // 
            // textBoxforunitprice
            // 
            this.textBoxforunitprice.Location = new System.Drawing.Point(239, 329);
            this.textBoxforunitprice.Name = "textBoxforunitprice";
            this.textBoxforunitprice.Size = new System.Drawing.Size(100, 20);
            this.textBoxforunitprice.TabIndex = 6;
            // 
            // textBoxforpackage
            // 
            this.textBoxforpackage.Location = new System.Drawing.Point(239, 355);
            this.textBoxforpackage.Name = "textBoxforpackage";
            this.textBoxforpackage.Size = new System.Drawing.Size(100, 20);
            this.textBoxforpackage.TabIndex = 6;
            // 
            // textBoxfordeleteID
            // 
            this.textBoxfordeleteID.Location = new System.Drawing.Point(615, 376);
            this.textBoxfordeleteID.Name = "textBoxfordeleteID";
            this.textBoxfordeleteID.Size = new System.Drawing.Size(100, 20);
            this.textBoxfordeleteID.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(513, 383);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "input ID for delete";
            this.label10.Click += new System.EventHandler(this.label6_Click);
            // 
            // Products
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxfordeleteID);
            this.Controls.Add(this.textBoxforpackage);
            this.Controls.Add(this.textBoxforunitprice);
            this.Controls.Add(this.textBoxforsupplierID);
            this.Controls.Add(this.textBoxforproductname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numericUpDownfortopnumber);
            this.Controls.Add(this.numericUpDownforlownumber);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.buttonproductsalesstate);
            this.Controls.Add(this.buttonforshowavailableproduct);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.back);
            this.Controls.Add(this.buttonforreadproducts);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Products";
            this.Text = "Products";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownforlownumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownfortopnumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonforreadproducts;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDownforlownumber;
        private System.Windows.Forms.NumericUpDown numericUpDownfortopnumber;
        private System.Windows.Forms.Button buttonforshowavailableproduct;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button buttonproductsalesstate;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxforproductname;
        private System.Windows.Forms.TextBox textBoxforsupplierID;
        private System.Windows.Forms.TextBox textBoxforunitprice;
        private System.Windows.Forms.TextBox textBoxforpackage;
        private System.Windows.Forms.TextBox textBoxfordeleteID;
        private System.Windows.Forms.Label label10;
    }
}