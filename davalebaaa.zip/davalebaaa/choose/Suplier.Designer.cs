﻿namespace choose
{
    partial class Suplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.readsupliers = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxforcompanyname = new System.Windows.Forms.TextBox();
            this.textBoxforcontactname = new System.Windows.Forms.TextBox();
            this.textBoxforcontacttitle = new System.Windows.Forms.TextBox();
            this.textBoxforcity = new System.Windows.Forms.TextBox();
            this.textBoxforcountry = new System.Windows.Forms.TextBox();
            this.textBoxforphone = new System.Windows.Forms.TextBox();
            this.Addsupplier = new System.Windows.Forms.Button();
            this.buttonforupdatesupplier = new System.Windows.Forms.Button();
            this.fordeletesupplier = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(49, 51);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(317, 186);
            this.dataGridView1.TabIndex = 0;
            // 
            // readsupliers
            // 
            this.readsupliers.Location = new System.Drawing.Point(152, 254);
            this.readsupliers.Name = "readsupliers";
            this.readsupliers.Size = new System.Drawing.Size(75, 23);
            this.readsupliers.TabIndex = 1;
            this.readsupliers.Text = "show";
            this.readsupliers.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(456, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "enter company name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(456, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "enter contact name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(456, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "enter contact title";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(456, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "enter city";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(456, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "enter country";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(456, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "enter phone";
            // 
            // textBoxforcompanyname
            // 
            this.textBoxforcompanyname.Location = new System.Drawing.Point(611, 51);
            this.textBoxforcompanyname.Name = "textBoxforcompanyname";
            this.textBoxforcompanyname.Size = new System.Drawing.Size(100, 20);
            this.textBoxforcompanyname.TabIndex = 3;
            // 
            // textBoxforcontactname
            // 
            this.textBoxforcontactname.Location = new System.Drawing.Point(611, 78);
            this.textBoxforcontactname.Name = "textBoxforcontactname";
            this.textBoxforcontactname.Size = new System.Drawing.Size(100, 20);
            this.textBoxforcontactname.TabIndex = 3;
            // 
            // textBoxforcontacttitle
            // 
            this.textBoxforcontacttitle.Location = new System.Drawing.Point(611, 104);
            this.textBoxforcontacttitle.Name = "textBoxforcontacttitle";
            this.textBoxforcontacttitle.Size = new System.Drawing.Size(100, 20);
            this.textBoxforcontacttitle.TabIndex = 3;
            // 
            // textBoxforcity
            // 
            this.textBoxforcity.Location = new System.Drawing.Point(611, 136);
            this.textBoxforcity.Name = "textBoxforcity";
            this.textBoxforcity.Size = new System.Drawing.Size(100, 20);
            this.textBoxforcity.TabIndex = 3;
            // 
            // textBoxforcountry
            // 
            this.textBoxforcountry.Location = new System.Drawing.Point(611, 163);
            this.textBoxforcountry.Name = "textBoxforcountry";
            this.textBoxforcountry.Size = new System.Drawing.Size(100, 20);
            this.textBoxforcountry.TabIndex = 3;
            // 
            // textBoxforphone
            // 
            this.textBoxforphone.Location = new System.Drawing.Point(611, 195);
            this.textBoxforphone.Name = "textBoxforphone";
            this.textBoxforphone.Size = new System.Drawing.Size(100, 20);
            this.textBoxforphone.TabIndex = 3;
            // 
            // Addsupplier
            // 
            this.Addsupplier.Location = new System.Drawing.Point(498, 265);
            this.Addsupplier.Name = "Addsupplier";
            this.Addsupplier.Size = new System.Drawing.Size(75, 23);
            this.Addsupplier.TabIndex = 1;
            this.Addsupplier.Text = "Add";
            this.Addsupplier.UseVisualStyleBackColor = true;
            // 
            // buttonforupdatesupplier
            // 
            this.buttonforupdatesupplier.Location = new System.Drawing.Point(611, 265);
            this.buttonforupdatesupplier.Name = "buttonforupdatesupplier";
            this.buttonforupdatesupplier.Size = new System.Drawing.Size(75, 23);
            this.buttonforupdatesupplier.TabIndex = 1;
            this.buttonforupdatesupplier.Text = "update";
            this.buttonforupdatesupplier.UseVisualStyleBackColor = true;
            // 
            // fordeletesupplier
            // 
            this.fordeletesupplier.Location = new System.Drawing.Point(94, 415);
            this.fordeletesupplier.Name = "fordeletesupplier";
            this.fordeletesupplier.Size = new System.Drawing.Size(75, 23);
            this.fordeletesupplier.TabIndex = 1;
            this.fordeletesupplier.Text = "delete";
            this.fordeletesupplier.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(81, 317);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "for delete";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(152, 370);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(82, 373);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "enter ID";
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.back.Location = new System.Drawing.Point(12, 12);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 1;
            this.back.Text = "<    back";
            this.back.UseVisualStyleBackColor = false;
            // 
            // Suplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBoxforphone);
            this.Controls.Add(this.textBoxforcountry);
            this.Controls.Add(this.textBoxforcity);
            this.Controls.Add(this.textBoxforcontacttitle);
            this.Controls.Add(this.textBoxforcontactname);
            this.Controls.Add(this.textBoxforcompanyname);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonforupdatesupplier);
            this.Controls.Add(this.fordeletesupplier);
            this.Controls.Add(this.back);
            this.Controls.Add(this.Addsupplier);
            this.Controls.Add(this.readsupliers);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Suplier";
            this.Text = "Suplier";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button readsupliers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxforcompanyname;
        private System.Windows.Forms.TextBox textBoxforcontactname;
        private System.Windows.Forms.TextBox textBoxforcontacttitle;
        private System.Windows.Forms.TextBox textBoxforcity;
        private System.Windows.Forms.TextBox textBoxforcountry;
        private System.Windows.Forms.TextBox textBoxforphone;
        private System.Windows.Forms.Button Addsupplier;
        private System.Windows.Forms.Button buttonforupdatesupplier;
        private System.Windows.Forms.Button fordeletesupplier;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button back;
    }
}