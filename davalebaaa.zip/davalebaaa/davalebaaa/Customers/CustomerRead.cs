﻿using System;
using System.Linq;
using davalebaaa.Models;

public class CustomerRead
{
    public static void ShowCustomers()
    {
        using var context = new ForSharpQuizContext();

        var customers = context.Customers.ToList();

        Console.WriteLine("\nCustomers List:");
        foreach (var customer in customers)
        {
            Console.WriteLine($"Id: {customer.Id}, Name: {customer.FirstName} {customer.LastName}");
        }
    }
}
