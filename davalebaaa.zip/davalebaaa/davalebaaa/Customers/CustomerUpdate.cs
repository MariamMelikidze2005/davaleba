﻿using System;
using System.Linq;
using davalebaaa.Models;

public class CustomerUpdate
{
    public static void UpdateCustomer()
    {
        using var context = new ForSharpQuizContext();
        Console.Write("Enter First Name to update: ");
        string firstName = Console.ReadLine();

        Console.Write("Enter Last Name to update: ");
        string lastName = Console.ReadLine();
        var customer = context.Customers.FirstOrDefault(c => c.FirstName == firstName && c.LastName == lastName);

        if (customer != null)
        {
            Console.WriteLine($"Found Customer: Id: {customer.Id}, First Name: {customer.FirstName}, Last Name: {customer.LastName}");
            Console.Write("Enter New First Name: ");
            string newFirstName = Console.ReadLine();

            Console.Write("Enter New Last Name: ");
            string newLastName = Console.ReadLine();
            if (!string.IsNullOrEmpty(newFirstName))
                customer.FirstName = newFirstName;

            if (!string.IsNullOrEmpty(newLastName))
                customer.LastName = newLastName;
            context.SaveChanges();
            Console.WriteLine("Customer updated successfully.");
        }
        else
        {
            Console.WriteLine("Customer not found.");
        }
    }
}
