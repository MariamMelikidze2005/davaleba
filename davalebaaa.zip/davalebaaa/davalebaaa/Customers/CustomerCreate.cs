﻿using davalebaaa.Models;
using System;

namespace davalebaaa.CustomerFunctions
{
    public class CustomerCreate
    {
        public static void CreateCustomer()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("First Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();

            var customer = new Customer
            {
                FirstName = firstName,
                LastName = lastName
            };

            context.Customers.Add(customer);
            context.SaveChanges();

            Console.WriteLine("Customer added successfully.");
        }
    }
}
