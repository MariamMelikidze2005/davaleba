﻿using System;
using System.Linq;
using davalebaaa.Models;

public class CustomerDelete
{
    public static void DeleteCustomer()
    {
        using var context = new ForSharpQuizContext();
        Console.Write("Enter First Name to delete: ");
        string firstName = Console.ReadLine();

        Console.Write("Enter Last Name to delete: ");
        string lastName = Console.ReadLine();
        var customer = context.Customers
            .FirstOrDefault(c => c.FirstName == firstName && c.LastName == lastName);

        if (customer != null)
        {
            Console.WriteLine($"Found Customer: Id: {customer.Id}, First Name: {customer.FirstName}, Last Name: {customer.LastName}");
            var orders = context.Orders
                .Where(o => o.CustomerId == customer.Id)
                .ToList();

            foreach (var order in orders)
            {
                var orderItems = context.OrderItems
                    .Where(oi => oi.OrderId == order.Id)
                    .ToList();

                context.OrderItems.RemoveRange(orderItems);
                context.Orders.Remove(order);
            }
            context.Customers.Remove(customer);
            context.SaveChanges();
            Console.WriteLine("Customer deleted successfully.");
        }
        else
        {
            Console.WriteLine("Customer not found.");
        }
    }
}
