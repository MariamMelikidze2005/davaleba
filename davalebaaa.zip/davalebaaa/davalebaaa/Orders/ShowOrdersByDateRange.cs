﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace OrderOperations
{
    public class ShowOrdersByDateRange
    {
        public static void Execute()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter start date (yyyy-mm-dd): ");
            DateTime startDate = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter end date (yyyy-mm-dd): ");
            DateTime endDate = DateTime.Parse(Console.ReadLine());

            var orders = context.Orders
                .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                .ToList();

            foreach (var order in orders)
            {
                Console.WriteLine($"Order #{order.Id} | Customer ID: {order.CustomerId} | Total: {order.TotalAmount} ₾ | Date: {order.OrderDate}");
            }
        }
    }
}
