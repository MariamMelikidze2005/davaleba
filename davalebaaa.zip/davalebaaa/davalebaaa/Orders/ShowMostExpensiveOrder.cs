﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace OrderOperations
{
    public class ShowMostExpensiveOrder
    {
        public static void Execute()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());

            var order = context.Orders
                .Where(o => o.CustomerId == customerId)
                .OrderByDescending(o => o.TotalAmount)
                .FirstOrDefault();

            if (order != null)
            {
                Console.WriteLine($"Most expensive order: #{order.Id} | Total: {order.TotalAmount} ₾ | Date: {order.OrderDate}");
            }
            else
            {
                Console.WriteLine("No orders found for this customer.");
            }
        }
    }
}
