﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace OrderOperations
{
    public class ShowCustomerOrders
    {
        public static void Execute()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Customer ID: ");
            int customerId = int.Parse(Console.ReadLine());

            var orders = context.Orders
                .Where(o => o.CustomerId == customerId)
                .ToList();

            if (orders.Any())
            {
                Console.WriteLine($"Orders for Customer {customerId}:");
                foreach (var order in orders)
                {
                    Console.WriteLine($"Order #{order.Id} | Date: {order.OrderDate} | Total: {order.TotalAmount} ₾");
                }
            }
            else
            {
                Console.WriteLine("This customer has no orders.");
            }
        }
    }
}
