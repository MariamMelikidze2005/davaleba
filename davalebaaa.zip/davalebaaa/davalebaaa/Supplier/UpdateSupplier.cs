﻿using System;
using System.Linq;
using davalebaaa.Models;

namespace davalebaaa.SupplierFunctions
{
    public class SupplierUpdate
    {
        public static void UpdateSupplier()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Supplier Id to update: ");
            int id = int.Parse(Console.ReadLine());

            var supplier = context.Suppliers.FirstOrDefault(s => s.Id == id);

            if (supplier != null)
            {
                Console.Write("New Company Name: ");
                supplier.CompanyName = Console.ReadLine();

                Console.Write("New Contact Name: ");
                supplier.ContactName = Console.ReadLine();

                Console.Write("New Contact Title: ");
                supplier.ContactTitle = Console.ReadLine();

                Console.Write("New City: ");
                supplier.City = Console.ReadLine();

                Console.Write("New Country: ");
                supplier.Country = Console.ReadLine();

                Console.Write("New Phone: ");
                supplier.Phone = Console.ReadLine();

                context.SaveChanges();
                Console.WriteLine("Supplier updated successfully.");
            }
            else
            {
                Console.WriteLine("Supplier not found.");
            }
        }
    }
}
