﻿using davalebaaa.Models;
using System;

namespace davalebaaa.SupplierFunctions
{
    public class SupplierCreate
    {
        public static void CreateSupplier()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Company Name: ");
            string companyName = Console.ReadLine();

            Console.Write("Enter Contact Name: ");
            string contactName = Console.ReadLine();

            Console.Write("Enter Contact Title: ");
            string contactTitle = Console.ReadLine();

            Console.Write("Enter City: ");
            string city = Console.ReadLine();

            Console.Write("Enter Country: ");
            string country = Console.ReadLine();

            Console.Write("Enter Phone: ");
            string phone = Console.ReadLine();

            var supplier = new Supplier
            {
                CompanyName = companyName,
                ContactName = contactName,
                ContactTitle = contactTitle,
                City = city,
                Country = country,
                Phone = phone
            };

            context.Suppliers.Add(supplier);
            context.SaveChanges();
            Console.WriteLine("Supplier created successfully.");
        }
    }
}
