﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace davalebaaa.SupplierFunctions
{
    public class SupplierRead
    {
        public static void ReadSupplier()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Supplier Id to view: ");
            int id = int.Parse(Console.ReadLine());

            var supplier = context.Suppliers
                .FirstOrDefault(s => s.Id == id);

            if (supplier != null)
            {
                Console.WriteLine($"Supplier Id: {supplier.Id}, Company Name: {supplier.CompanyName}, Contact Name: {supplier.ContactName}, City: {supplier.City}, Country: {supplier.Country}, Phone: {supplier.Phone}");
            }
            else
            {
                Console.WriteLine("Supplier not found.");
            }
        }
    }
}
