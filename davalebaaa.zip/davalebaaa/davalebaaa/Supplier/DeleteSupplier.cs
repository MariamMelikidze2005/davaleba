﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace davalebaaa.SupplierFunctions
{
    public class SupplierDelete
    {
        public static void DeleteSupplier()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Supplier Id to delete: ");
            int id = int.Parse(Console.ReadLine());

            var supplier = context.Suppliers.FirstOrDefault(s => s.Id == id);

            if (supplier != null)
            {
                // Check if the supplier has any products associated
                var products = context.Products.Where(p => p.SupplierId == id).ToList();

                if (products.Count > 0)
                {
                    Console.WriteLine("The supplier has products associated with it.");
                    Console.Write("Do you want to delete all associated products as well? (yes/no): ");
                    string response = Console.ReadLine()?.ToLower();

                    if (response == "yes")
                    {
                        // Delete all associated products
                        context.Products.RemoveRange(products);
                        Console.WriteLine("All associated products have been deleted.");
                    }
                    else
                    {
                        Console.WriteLine("Products associated with this supplier were not deleted.");
                        return;
                    }
                }

                context.Suppliers.Remove(supplier);
                context.SaveChanges();
                Console.WriteLine("Supplier deleted successfully.");
            }
            else
            {
                Console.WriteLine("Supplier not found.");
            }
        }
    }
}
