﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace ProductOperations
{
    public class SearchProductsByPriceRange
    {
        public static void Execute()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter minimum price: ");
            decimal minPrice = decimal.Parse(Console.ReadLine());

            Console.Write("Enter maximum price: ");
            decimal maxPrice = decimal.Parse(Console.ReadLine());

            var products = context.Products
                .Where(p => p.UnitPrice >= minPrice && p.UnitPrice <= maxPrice)
                .ToList();

            foreach (var product in products)
            {
                Console.WriteLine($"#{product.Id} - {product.ProductName} | Price: {product.UnitPrice} ₾");
            }
        }
    }
}
