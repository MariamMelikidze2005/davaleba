﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace ProductOperations
{
    public class ShowAvailableProducts
    {
        public static void Execute()
        {
            using var context = new ForSharpQuizContext();

            var products = context.Products
                .Where(p => !p.IsDiscontinued)
                .ToList();

            if (products.Any())
            {
                Console.WriteLine("Available Products:");
                foreach (var product in products)
                {
                    Console.WriteLine($"#{product.Id} - {product.ProductName} | Price: {product.UnitPrice} ₾ | Package: {product.Package}");
                }
            }
            else
            {
                Console.WriteLine("No available products.");
            }
        }
    }
}
