﻿using System;
using System.Linq;
using davalebaaa.Models;

namespace davalebaaa.ProductFunctions
{
    public class ProductCreate
    {
        public static void CreateProduct()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Product Name: ");
            string productName = Console.ReadLine();

            Console.Write("Enter Supplier Id: ");
            int supplierId = int.Parse(Console.ReadLine());

            Console.Write("Enter Unit Price: ");
            decimal unitPrice = decimal.Parse(Console.ReadLine());

            Console.Write("Enter Package: ");
            string package = Console.ReadLine();

            var product = new Product
            {
                ProductName = productName,
                SupplierId = supplierId,
                UnitPrice = unitPrice,
                Package = package
            };

            context.Products.Add(product);
            context.SaveChanges();
            Console.WriteLine("Product created successfully.");
        }
    }
}
