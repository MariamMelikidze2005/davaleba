﻿using System;
using System.Linq;
using davalebaaa.Models;

namespace davalebaaa.ProductFunctions
{
    public class ProductRead
    {
        public static void ReadProduct()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Product Id to view: ");
            int id = int.Parse(Console.ReadLine());

            var product = context.Products
                .FirstOrDefault(p => p.Id == id);

            if (product != null)
            {
                Console.WriteLine($"Product Id: {product.Id}, Name: {product.ProductName}, Supplier Id: {product.SupplierId}, Price: {product.UnitPrice}, Package: {product.Package}");
            }
            else
            {
                Console.WriteLine("Product not found.");
            }
        }
    }
}
