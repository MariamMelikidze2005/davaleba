﻿using System;
using davalebaaa.Models;

namespace davalebaaa.ProductFunctions
{
    public class ProductUpdate
    {
        public static void UpdateProduct()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Product Id to update: ");
            int id = int.Parse(Console.ReadLine());

            var product = context.Products.FirstOrDefault(p => p.Id == id);

            if (product != null)
            {
                Console.Write("New Product Name: ");
                product.ProductName = Console.ReadLine();

                Console.Write("New Supplier Id: ");
                product.SupplierId = int.Parse(Console.ReadLine());

                Console.Write("New Unit Price: ");
                product.UnitPrice = decimal.Parse(Console.ReadLine());

                Console.Write("New Package: ");
                product.Package = Console.ReadLine();

                context.SaveChanges();
                Console.WriteLine("Product updated successfully.");
            }
            else
            {
                Console.WriteLine("Product not found.");
            }
        }
    }
}
