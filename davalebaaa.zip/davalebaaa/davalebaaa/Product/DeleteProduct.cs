﻿using System;
using System.Linq;
using davalebaaa.Models;

namespace davalebaaa.ProductFunctions
{
    public class ProductDelete
    {
        public static void DeleteProduct()
        {
            using var context = new ForSharpQuizContext();

            Console.Write("Enter Product Id to delete: ");
            int id = int.Parse(Console.ReadLine());

            var product = context.Products.FirstOrDefault(p => p.Id == id);

            if (product != null)
            {
                context.Products.Remove(product);
                context.SaveChanges();
                Console.WriteLine("Product deleted successfully.");
            }
            else
            {
                Console.WriteLine("Product not found.");
            }
        }
    }
}
