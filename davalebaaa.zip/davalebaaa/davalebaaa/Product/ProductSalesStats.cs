﻿using davalebaaa.Models;
using System;
using System.Linq;

namespace ProductOperations
{
    public class ProductSalesStats
    {
        public static void Execute()
        {
            using var context = new ForSharpQuizContext();

            var stats = context.OrderItems
                .GroupBy(oi => oi.ProductId)
                .Select(g => new
                {
                    ProductId = g.Key,
                    SalesCount = g.Count()
                })
                .Join(context.Products,
                      stat => stat.ProductId,
                      prod => prod.Id,
                      (stat, prod) => new { prod.ProductName, stat.SalesCount })
                .OrderByDescending(p => p.SalesCount)
                .ToList();

            foreach (var item in stats)
            {
                Console.WriteLine($"{item.ProductName}: Sold {item.SalesCount} times");
            }
        }
    }
}
