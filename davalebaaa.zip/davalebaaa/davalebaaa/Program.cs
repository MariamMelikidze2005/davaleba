﻿using davalebaaa;
using OrderOperations;
using ProductOperations;
using davalebaaa.CustomerFunctions;
using davalebaaa.ProductFunctions;
using davalebaaa.SupplierFunctions;
using System;

namespace davalebaaa
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n--- MAIN MENU ---");
                Console.WriteLine("1. Customers");
                Console.WriteLine("2. Orders");
                Console.WriteLine("3. Product");
                Console.WriteLine("4. Supplier");
                Console.WriteLine("0. Exit");
                Console.Write("Choose: ");
                var categoryChoice = Console.ReadLine();

                switch (categoryChoice)
                {
                    case "1":
                        ShowCustomerMenu();
                        break;
                    case "2":
                        ShowOrderMenu();
                        break;
                    case "3":
                        ShowProductMenu();
                        break;
                    case "4":
                        ShowSupplierMenu();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Invalid option.");
                        break;
                }
            }
        }

        static void ShowCustomerMenu()
        {
            Console.WriteLine("\n--- CUSTOMER MENU ---");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. Show Customers");
            Console.WriteLine("3. Update Customer");
            Console.WriteLine("4. Delete Customer");
            Console.Write("Choose: ");
            var input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    CustomerCreate.CreateCustomer();
                    break;
                case "2":
                    CustomerRead.ShowCustomers();
                    break;
                case "3":
                    CustomerUpdate.UpdateCustomer();
                    break;
                case "4":
                    CustomerDelete.DeleteCustomer();
                    break;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }

        static void ShowOrderMenu()
        {
            Console.WriteLine("\n--- ORDER MENU ---");
            Console.WriteLine("1. Show Customer Orders");
            Console.WriteLine("2. Show Most Expensive Order");
            Console.WriteLine("3. Show Orders by Date Range");
            Console.Write("Choose: ");
            var input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    ShowCustomerOrders.Execute();
                    break;
                case "2":
                    ShowMostExpensiveOrder.Execute();
                    break;
                case "3":
                    ShowOrdersByDateRange.Execute();
                    break;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }

        static void ShowProductMenu()
        {
            Console.WriteLine("\n--- PRODUCT MENU ---");
            Console.WriteLine("1. Create Product");
            Console.WriteLine("2. Show Products");
            Console.WriteLine("3. Update Product");
            Console.WriteLine("4. Delete Product");
            Console.WriteLine("5. Show Product Sales Stats");
            Console.WriteLine("6. Search Products By Price");
            Console.WriteLine("7. Show Available Products");
            Console.Write("Choose: ");
            var input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    ProductCreate.CreateProduct();
                    break;
                case "2":
                    ProductRead.ReadProduct();
                    break;
                case "3":
                    ProductUpdate.UpdateProduct();
                    break;
                case "4":
                    ProductDelete.DeleteProduct();
                    break;
                case "5":
                    ProductSalesStats.Execute();
                    break;
                case "6":
                    SearchProductsByPriceRange.Execute();
                    break;
                case "7":
                    ShowAvailableProducts.Execute();
                    break;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }

        static void ShowSupplierMenu()
        {
            Console.WriteLine("\n--- SUPPLIER MENU ---");
            Console.WriteLine("1. Create Supplier");
            Console.WriteLine("2. Show Suppliers");
            Console.WriteLine("3. Update Supplier");
            Console.WriteLine("4. Delete Supplier");
            Console.Write("Choose: ");
            var input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    SupplierCreate.CreateSupplier();
                    break;
                case "2":
                    SupplierRead.ReadSupplier();
                    break;
                case "3":
                    SupplierUpdate.UpdateSupplier();
                    break;
                case "4":
                    SupplierDelete.DeleteSupplier();
                    break;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }
}
